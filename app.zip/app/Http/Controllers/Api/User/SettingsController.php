<?php

namespace App\Http\Controllers\Api\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class SettingsController extends Controller
{
    /**
     * Get application settings/keys
     */
    public function index(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => 'Settings retrieved successfully',
            'data' => [
                'public_key' => config('services.client_app.public_key'),
                'client_secret' => config('services.client_app.client_secret'),
            ]
        ]);
    }
}
